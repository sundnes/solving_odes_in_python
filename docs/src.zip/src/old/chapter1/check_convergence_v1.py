from forward_euler_class_v2 import *
import numpy as np

def rhs(u,t):
    return u

def exact(t):
    return np.exp(t)

solver = ForwardEuler_v2(rhs)
solver.set_initial_condition(1.0)

T = 3.0
N = 30

print(f'Time step (dt)   Error (e)      e/dt')
for _ in range(10):
    time = np.linspace(0,T,N+1)
    dt = T/N
    u,t = solver.solve(time)
    e = abs(u[-1]-exact(time[-1]))
    print(f'{dt:<14.7f}   {e:<12.7f}   {e/dt:5.4f}')
    N = N*2




