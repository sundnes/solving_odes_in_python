from math import sin

class Pendulum:
    def __init__(self, L, g = 9.81):
        self.L = L 
        self.g = g 
    
    def __call__(self,t,u):
        theta, omega = u
        dtheta = omega
        domega = -self.g/self.L * sin(theta)
        return [dtheta, domega]