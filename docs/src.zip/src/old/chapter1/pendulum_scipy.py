from scipy.integrate import solve_ivp
import numpy as np
import matplotlib.pyplot as plt

from pendulum import Pendulum


problem = Pendulum(L=1)
t_span = (0,10.0)
u0 = (np.pi/4, 0)

#t_eval = np.linspace(0,10.0,1001)
rtol = 1e-6
solution = solve_ivp(problem, t_span, u0,rtol=rtol)

plt.plot(solution.t, solution.y[0,:])
plt.plot(solution.t, solution.y[1,:])
plt.legend([r'$\theta$',r'$\omega$'])
plt.show()


