from ImplicitRK_v2 import *


class SDIRK_opt(ImplicitRK):

    def compute_jac(self, u, c_i, k_sum):
        # """
        eps = 1e-8
        t = self.t
        u = np.asarray(u)
        neq = self.neq
        f0 = self.f(t, u)
        u_eps = np.copy(u)
        df = np.zeros((neq, neq))
        for i in range(neq):
            u_eps[i] += eps
            f_eps = self.f(t, u_eps)
            df[i, :] = (f_eps - f0) / eps
            u_eps[i] -= eps
        t, n = self.t, self.n
        dt = t[n + 1] - t[n]
        """
        neq = self.neq
        t,n = self.t,self.n
        dt = t[n+1] - t[n]
        df = self.model.jac(self.t,u)
        """
        jac = np.identity(neq) - self.gamma * dt * df
        return jac

    def stage_eq(self, k, c_i, k_sum):
        u, f, n, t = self.u, self.f, self.n, self.t
        dt = t[n + 1] - t[n]
        gamma = self.gamma

        return k - f(t[n] + c_i * dt, u[n] + dt * (k_sum + gamma * k))

    def solve_stages(self):
        u, f, n, t = self.u, self.f, self.n, self.t
        a, c = self.a, self.c
        s = self.stages

        k = f(t[n], u[n])  # initial guess for first stage
        k_sum = np.zeros_like(k)
        k_all = []

        for i in range(s):
            k_sum = sum(a_ * k_ for a_, k_ in zip(a[i, :i], k_all))
            k = root(
                self.stage_eq,
                k,
                jac=self.compute_jac,
                args=(
                    c[i],
                    k_sum)).x
            # print(sol.keys())
            # exit()
            #self.total_its += sol.nit
            #k = sol.x
            k_all.append(k)

        return k_all


class SDIRK2_opt(SDIRK_opt):
    def __init__(self, f):
        super().__init__(f)
        self.stages = 2
        gamma = (2 - np.sqrt(2)) / 2
        self.gamma = gamma
        self.a = np.array([[gamma, 0],
                           [1 - gamma, gamma]])
        self.c = np.array([gamma, 1])
        self.b = np.array([1 - gamma, gamma])

        self.total_its = 0


if __name__ == "__main__":
    from vanderpol import VanderPol
    mu = 10
    model = VanderPol(mu=mu)
    solver = SDIRK2_opt(model)
    solver.set_initial_condition([1.0, 0.0])
    df = solver.compute_jac(0, [1.0, 0.0])
    print(df)
